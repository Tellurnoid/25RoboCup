# KiCad Curve Tracks

Filling the gaps between tracks with arc

## Install

```
C:\Users\<name>\AppData\Roaming\kicad\scripting\plugins\
```
