import pcbnew
from .curve_tracks import CurveTracks

CurveTracks().register()
